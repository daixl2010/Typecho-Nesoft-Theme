# Typecho-Nesoft-Theme

#### 简介

基于Bootstrap的响应式主题！

项目主页：http://www.nesoft.cn

测试平台：typecho 1.0

==============================

#### 如何使用

点击右侧的`Download ZIP`按钮，下载完成之后解压得到plugins、resources、Nesoft三个文件夹，其中Nesoft为主题上传到'usr/themes'目录，resources文件夹放在usr目录，plugins文件夹下的插件放在'usr/plugins'目录，然后在后台启用主题。

==============================

#### 更新纪录

##### 2016-03-10

* V1.0.1 
* 解决评论头像显示错误；

##### 2016-03-17

* V1.0.2 
* 修复footer.php中copyrights缺少/div标签；
* 修改footer样式，小屏幕居中显示。

##### 2016-03-20

* V1.0.3 
* 后台自主选择是否显示微缩图。
* 添加微缩图插件，使微缩图优先显示文章中图片。
* 修改部分样式。

##### 2016-03-21

* V1.0.4
* 添加侧边栏最新文章图文展示

==============================

#### 问题反馈

在[这里](http://www.nesoft.cn/message)提出使用中的问题，我会在时间允许的第一时间进行处理。

另外，欢迎fork & star。

==============================

#### LICENSE

[GPL LICENSE](https://github.com/daixl2010/Typecho-Nesoft-Theme/blob/master/LICENSE)

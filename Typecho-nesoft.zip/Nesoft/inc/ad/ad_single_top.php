<?php if($this->options->ad_single_top) : ?>
	<div class="ad ad-single-top text-center">
		<?php echo $this->options->ad_single_top; ?>
	</div>
<?php endif; ?>

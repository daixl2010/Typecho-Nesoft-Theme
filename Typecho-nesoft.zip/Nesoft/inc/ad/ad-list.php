<?php if($this->options->ad_list) : ?>
	<div class="ad ad-index-list text-center">
		<?php echo $this->options->ad_list; ?>
	</div>
<?php endif; ?>

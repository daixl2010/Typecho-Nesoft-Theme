<?php if($this->options->ad_comments_top) : ?>
	<div class="ad ad-comments-top text-center">
		<?php echo $this->options->ad_comments_top; ?>
	</div>
<?php endif; ?>

<?php if($this->options->ad_widget_top) : ?>
	<div class="ad ad-widget-top text-center">
		<?php echo $this->options->ad_widget_top; ?>
	</div>
<?php endif; ?>

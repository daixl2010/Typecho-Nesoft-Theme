<div class="ad ad-suspend text-center">
	<?php echo stripslashes(of_get_option('ad_suspend'));?>
</div>
